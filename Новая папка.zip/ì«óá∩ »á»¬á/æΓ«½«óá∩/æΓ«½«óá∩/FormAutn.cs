﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Столовая
{
    public partial class authorization : Form
    {
        public authorization()
        {
            InitializeComponent();
        }

                private void button1_Click(object sender, EventArgs e)
                {
                    using (var db = new СтоловаяEntities())
                    {
                        var res = db.Пользователь.FirstOrDefault(item => item.Логин == loginBox.Text && item.Пароль == passwordBox.Text);
                        if (res != null)
                        {
                            var d = db.Пользователь.FirstOrDefault(item => item.Логин == loginBox.Text);
                                    
                    
                                if (res.Роль == "Заведующий")

                                {
                                    MessageBox.Show("Вы вошли под учетной записью, " + res.Роль);
                                    Form zav = new FormZav();
                                    zav.Show();
                                    this.Hide();
                                }


                                if (res.Роль == "Администратор")
                                {
                                    MessageBox.Show("Вы вошли под учетной записью, " + res.Роль);
                                    Form reg = new registrazia();
                                    reg.Show();
                                    this.Hide();
                                }

                                //else
                                //{
                                //    var s = db.Пользователь.FirstOrDefault(item => item.Логин == loginBox.Text);
                                //    MessageBox.Show("Неверный логин или пароль");
                                //}



                        }

                    }
                }

                private void authorization_FormClosing(object sender, FormClosingEventArgs e)
                {
                    Application.Exit(); // Остановить приложение
                }   
    }
}
