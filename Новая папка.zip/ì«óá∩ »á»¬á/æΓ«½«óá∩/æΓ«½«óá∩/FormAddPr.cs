﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Столовая
{
    public partial class FormAddPr : Form
    {
        public FormAddPr()
        {
            InitializeComponent();
        }

        private void FormAddPr_Load_1(object sender, EventArgs e)
        {

        }
      

        private void FormAddPr_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); // Остановить приложение

        }

        private void addpr_Click(object sender, EventArgs e)
        {
            using (var db = new СтоловаяEntities())
            {
                var pr = new Склад();
                pr.Наименование = name.Text;
                pr.Колличество = Convert.ToInt32(kollvo.Text); 
                pr.ЕдИзм = ediz.Text;
                pr.ЦенаЗа1 = Convert.ToInt32(moneyed.Text);
                pr.Цена = Convert.ToInt32(money.Text);
                pr.ДатаДоставки = dateTimePickerpr.Value;

                if (pr != null)

                {
                    db.Склад.Add(pr);
                    db.SaveChanges();                    
                    MessageBox.Show("Сохранено");
                }
                else
                {
                    MessageBox.Show("Не сохранено");

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form zav = new FormZav();
            zav.Show();
            this.Hide();
        }
    }
}
