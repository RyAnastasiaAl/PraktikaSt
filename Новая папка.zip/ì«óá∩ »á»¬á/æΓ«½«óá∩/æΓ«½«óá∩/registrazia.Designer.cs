﻿namespace Столовая
{
    partial class registrazia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.registr = new System.Windows.Forms.Button();
            this.surname = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.patronymic = new System.Windows.Forms.Label();
            this.datebirth = new System.Windows.Forms.Label();
            this.surnameBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.patronymicBox = new System.Windows.Forms.TextBox();
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.loginBox = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.login = new System.Windows.Forms.Label();
            this.datebirthPicker = new System.Windows.Forms.DateTimePicker();
            this.Rol = new System.Windows.Forms.Label();
            this.RolBox = new System.Windows.Forms.ComboBox();
            this.пользовательBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.столоваяDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.столоваяDataSet = new Столовая.СтоловаяDataSet();
            this.пользовательTableAdapter = new Столовая.СтоловаяDataSetTableAdapters.ПользовательTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.пользовательBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.столоваяDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.столоваяDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // registr
            // 
            this.registr.Location = new System.Drawing.Point(247, 228);
            this.registr.Name = "registr";
            this.registr.Size = new System.Drawing.Size(113, 23);
            this.registr.TabIndex = 0;
            this.registr.Text = "Регистрация";
            this.registr.UseVisualStyleBackColor = true;
            this.registr.Click += new System.EventHandler(this.registr_Click);
            // 
            // surname
            // 
            this.surname.AutoSize = true;
            this.surname.Location = new System.Drawing.Point(33, 33);
            this.surname.Name = "surname";
            this.surname.Size = new System.Drawing.Size(56, 13);
            this.surname.TabIndex = 1;
            this.surname.Text = "Фамилия";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(33, 59);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(29, 13);
            this.name.TabIndex = 2;
            this.name.Text = "Имя";
            // 
            // patronymic
            // 
            this.patronymic.AutoSize = true;
            this.patronymic.Location = new System.Drawing.Point(33, 85);
            this.patronymic.Name = "patronymic";
            this.patronymic.Size = new System.Drawing.Size(54, 13);
            this.patronymic.TabIndex = 3;
            this.patronymic.Text = "Отчество";
            // 
            // datebirth
            // 
            this.datebirth.AutoSize = true;
            this.datebirth.Location = new System.Drawing.Point(33, 111);
            this.datebirth.Name = "datebirth";
            this.datebirth.Size = new System.Drawing.Size(86, 13);
            this.datebirth.TabIndex = 4;
            this.datebirth.Text = "Дата рождения";
            // 
            // surnameBox
            // 
            this.surnameBox.Location = new System.Drawing.Point(151, 26);
            this.surnameBox.Name = "surnameBox";
            this.surnameBox.Size = new System.Drawing.Size(200, 20);
            this.surnameBox.TabIndex = 5;
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(151, 52);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(200, 20);
            this.nameBox.TabIndex = 6;
            // 
            // patronymicBox
            // 
            this.patronymicBox.Location = new System.Drawing.Point(151, 78);
            this.patronymicBox.Name = "patronymicBox";
            this.patronymicBox.Size = new System.Drawing.Size(200, 20);
            this.patronymicBox.TabIndex = 7;
            // 
            // passwordBox
            // 
            this.passwordBox.Location = new System.Drawing.Point(151, 189);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.Size = new System.Drawing.Size(130, 20);
            this.passwordBox.TabIndex = 12;
            // 
            // loginBox
            // 
            this.loginBox.Location = new System.Drawing.Point(151, 163);
            this.loginBox.Name = "loginBox";
            this.loginBox.Size = new System.Drawing.Size(130, 20);
            this.loginBox.TabIndex = 11;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Location = new System.Drawing.Point(33, 196);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(88, 13);
            this.password.TabIndex = 10;
            this.password.Text = "Введите пароль";
            // 
            // login
            // 
            this.login.AutoSize = true;
            this.login.Location = new System.Drawing.Point(33, 170);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(81, 13);
            this.login.TabIndex = 9;
            this.login.Text = "Введите логин";
            // 
            // datebirthPicker
            // 
            this.datebirthPicker.Location = new System.Drawing.Point(151, 104);
            this.datebirthPicker.Name = "datebirthPicker";
            this.datebirthPicker.Size = new System.Drawing.Size(200, 20);
            this.datebirthPicker.TabIndex = 13;
            // 
            // Rol
            // 
            this.Rol.AutoSize = true;
            this.Rol.Location = new System.Drawing.Point(33, 139);
            this.Rol.Name = "Rol";
            this.Rol.Size = new System.Drawing.Size(32, 13);
            this.Rol.TabIndex = 14;
            this.Rol.Text = "Роль";
            // 
            // RolBox
            // 
            this.RolBox.DataSource = this.пользовательBindingSource;
            this.RolBox.DisplayMember = "Роль";
            this.RolBox.FormattingEnabled = true;
            this.RolBox.Location = new System.Drawing.Point(151, 131);
            this.RolBox.Name = "RolBox";
            this.RolBox.Size = new System.Drawing.Size(121, 21);
            this.RolBox.TabIndex = 15;
            this.RolBox.ValueMember = "Роль";
            // 
            // пользовательBindingSource
            // 
            this.пользовательBindingSource.DataMember = "Пользователь";
            this.пользовательBindingSource.DataSource = this.столоваяDataSetBindingSource;
            // 
            // столоваяDataSetBindingSource
            // 
            this.столоваяDataSetBindingSource.DataSource = this.столоваяDataSet;
            this.столоваяDataSetBindingSource.Position = 0;
            // 
            // столоваяDataSet
            // 
            this.столоваяDataSet.DataSetName = "СтоловаяDataSet";
            this.столоваяDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользовательTableAdapter
            // 
            this.пользовательTableAdapter.ClearBeforeFill = true;
            // 
            // registrazia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 298);
            this.Controls.Add(this.RolBox);
            this.Controls.Add(this.Rol);
            this.Controls.Add(this.datebirthPicker);
            this.Controls.Add(this.passwordBox);
            this.Controls.Add(this.loginBox);
            this.Controls.Add(this.password);
            this.Controls.Add(this.login);
            this.Controls.Add(this.patronymicBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.surnameBox);
            this.Controls.Add(this.datebirth);
            this.Controls.Add(this.patronymic);
            this.Controls.Add(this.name);
            this.Controls.Add(this.surname);
            this.Controls.Add(this.registr);
            this.Name = "registrazia";
            this.Text = "Регистрация";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.registrazia_FormClosing);
            this.Load += new System.EventHandler(this.registrazia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.пользовательBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.столоваяDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.столоваяDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button registr;
        private System.Windows.Forms.Label surname;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label patronymic;
        private System.Windows.Forms.Label datebirth;
        private System.Windows.Forms.TextBox surnameBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox patronymicBox;
        private System.Windows.Forms.TextBox passwordBox;
        private System.Windows.Forms.TextBox loginBox;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label login;
        private System.Windows.Forms.DateTimePicker datebirthPicker;
        private System.Windows.Forms.Label Rol;
        private System.Windows.Forms.ComboBox RolBox;
        private System.Windows.Forms.BindingSource столоваяDataSetBindingSource;
        private СтоловаяDataSet столоваяDataSet;
        private System.Windows.Forms.BindingSource пользовательBindingSource;
        private СтоловаяDataSetTableAdapters.ПользовательTableAdapter пользовательTableAdapter;
    }
}