﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;


namespace Столовая
{
    public partial class FormZav : Form
    {
        Bitmap y;
        PrintDocument printDocument = new PrintDocument();
        public FormZav()
        {
           
            InitializeComponent();
            printDocument.PrintPage += PrintPageHandler;
        }
        private string result = " ";
        private void FormZav_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "столоваяDataSet.Склад". При необходимости она может быть перемещена или удалена.
            //this.складTableAdapter.Fill(this.столоваяDataSet.Склад);
            using (var db = new СтоловаяEntities())
            {
                var s = db.Склад.Select(a =>
                new
                {
                    a.idПродукт,
                    a.Наименование,
                    a.Колличество,
                    a.ЕдИзм,
                    a.ЦенаЗа1,
                    a.Цена,
                    a.ДатаДоставки

                });
                productsGridView.DataSource = s.ToList();
            }
        }

        private void Addpr_Click(object sender, EventArgs e)
        {
            Form addpr = new FormAddPr();
            addpr.Show();
            this.Hide();
        }

        private void FormZav_FormClosing(object sender, FormClosingEventArgs e)
        {
          Application.Exit(); // Остановить приложение
            
        }

        private void print_Click(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog(); //диалоговое окно настройки печати
            printDialog.Document = printDocument;
            if(printDialog.ShowDialog() == DialogResult.OK)
            {
                printDialog.Document.Print();
            }


        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {
        }

         void PrintPageHandler(object sender, PrintPageEventArgs e)
        {
            
            y = new Bitmap(productsGridView.Size.Width + 100, productsGridView.Size.Height + 100);
            productsGridView.DrawToBitmap(y, productsGridView.Bounds);
            e.Graphics.DrawImage(y, 0, 0);

        }

    }
}
