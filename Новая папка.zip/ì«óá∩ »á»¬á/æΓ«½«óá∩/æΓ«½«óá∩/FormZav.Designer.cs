﻿namespace Столовая
{
    partial class FormZav
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormZav));
            this.productsGridView = new System.Windows.Forms.DataGridView();
            this.Addpr = new System.Windows.Forms.Button();
            this.print = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.productsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // productsGridView
            // 
            this.productsGridView.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.productsGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.productsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.productsGridView.Location = new System.Drawing.Point(12, 12);
            this.productsGridView.Name = "productsGridView";
            this.productsGridView.Size = new System.Drawing.Size(786, 387);
            this.productsGridView.TabIndex = 0;
            // 
            // Addpr
            // 
            this.Addpr.Location = new System.Drawing.Point(723, 415);
            this.Addpr.Name = "Addpr";
            this.Addpr.Size = new System.Drawing.Size(75, 23);
            this.Addpr.TabIndex = 1;
            this.Addpr.Text = "Добавить";
            this.Addpr.UseVisualStyleBackColor = true;
            this.Addpr.Click += new System.EventHandler(this.Addpr_Click);
            // 
            // print
            // 
            this.print.Location = new System.Drawing.Point(633, 415);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(75, 23);
            this.print.TabIndex = 2;
            this.print.Text = "Печать";
            this.print.UseVisualStyleBackColor = true;
            this.print.Click += new System.EventHandler(this.print_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // FormZav
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 450);
            this.Controls.Add(this.print);
            this.Controls.Add(this.Addpr);
            this.Controls.Add(this.productsGridView);
            this.Name = "FormZav";
            this.Text = "Заведующий";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormZav_FormClosing);
            this.Load += new System.EventHandler(this.FormZav_Load);
            ((System.ComponentModel.ISupportInitialize)(this.productsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView productsGridView;
        private System.Windows.Forms.Button Addpr;
        private System.Windows.Forms.Button print;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}